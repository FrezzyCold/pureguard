plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.pureguard.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pureguard.ai"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildFeatures {
        viewBinding = true
    }

    aaptOptions {
        noCompress("tflite") // Важно: не сжимать веса TFLite в APK
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    // TensorFlow Lite On-Device AI Engine
    implementation("org.tensorflow:tensorflow-lite:2.16.1")
    implementation("org.tensorflow:tensorflow-lite-gpu:2.16.1")
    implementation("org.tensorflow:tensorflow-lite-support:0.4.4")

    // Корутины для неблокирующей обработки
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
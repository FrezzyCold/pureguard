package com.pureguard.ai.ai

import android.graphics.Bitmap
import kotlin.math.abs

class FrameDiffEngine(private val thresholdPercent: Float = 10.0f) {

    private var previousBlockHashes: LongArray? = null
    private val gridSize = 8 // Сетка 8x8 блоков = 64 точки

    fun hasSignificantChange(bitmap: Bitmap): Boolean {
        val currentHashes = LongArray(gridSize * gridSize)
        val stepX = bitmap.width / gridSize
        val stepY = bitmap.height / gridSize

        var index = 0
        for (y in 0 until gridSize) {
            for (x in 0 until gridSize) {
                val px = bitmap.getPixel(x * stepX + stepX / 2, y * stepY + stepY / 2)
                currentHashes[index++] = px.toLong()
            }
        }

        val prev = previousBlockHashes
        previousBlockHashes = currentHashes

        if (prev == null) return true // Первый кадр проверяем всегда

        var changedPoints = 0
        for (i in currentHashes.indices) {
            val rDiff = abs(((currentHashes[i] shr 16) and 0xFF) - ((prev[i] shr 16) and 0xFF))
            val gDiff = abs(((currentHashes[i] shr 8) and 0xFF) - ((prev[i] shr 8) and 0xFF))
            val bDiff = abs((currentHashes[i] and 0xFF) - (prev[i] and 0xFF))

            if ((rDiff + gDiff + bDiff) > 60) {
                changedPoints++
            }
        }

        val changePercentage = (changedPoints.toFloat() / currentHashes.size) * 100f
        return changePercentage >= thresholdPercent
    }
}
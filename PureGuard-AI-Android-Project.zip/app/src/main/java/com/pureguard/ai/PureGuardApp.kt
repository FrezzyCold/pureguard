package com.pureguard.ai

import android.app.Application

class PureGuardApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}

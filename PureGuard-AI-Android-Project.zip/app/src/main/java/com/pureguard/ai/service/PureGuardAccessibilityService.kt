package com.pureguard.ai.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.util.Log

class PureGuardAccessibilityService : AccessibilityService() {

    var currentForegroundPackage: String = ""
        private set

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i("PureGuard", "Служба защиты доступности подключена")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString()
            if (!pkg.isNullOrEmpty() && !pkg.contains("com.pureguard.ai")) {
                currentForegroundPackage = pkg
            }
        }
    }

    /**
     * ЭКСТРЕННЫЙ ВЫБРОС:
     * Вызывает на уровне Android OS системную команду нажатия кнопки "Домой".
     * Работает абсолютно везде: в Telegram, Chrome, TikTok, галерее, любых браузерах.
     */
    fun sendHomeAction(): Boolean {
        Log.w("PureGuard", "ОБНАРУЖЕН ЗАПРЕЩЕННЫЙ КОНТЕНТ! Выбрасываем из: $currentForegroundPackage")
        return performGlobalAction(GLOBAL_ACTION_HOME)
    }

    override fun onInterrupt() {
        Log.e("PureGuard", "Accessibility Interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    companion object {
        var instance: PureGuardAccessibilityService? = null
            private set
    }
}
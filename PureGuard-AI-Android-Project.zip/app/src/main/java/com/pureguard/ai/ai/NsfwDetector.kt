package com.pureguard.ai.ai

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.CompatibilityList
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import org.tensorflow.lite.support.common.FileUtil
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class DetectionResult(
    val isNsfw: boolean,
    val confidence: Float,
    val category: String,
    val inferenceTimeMs: Long
)

class NsfwDetector(context: Context) {

    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null
    private var nnApiDelegate: NnApiDelegate? = null

    companion object {
        // Квантованная модель 2.8 МБ из папки assets/models/
        private const val MODEL_PATH = "models/mobilenet_v3_nsfw_int8.tflite"
        private const val INPUT_SIZE = 224
        private const val NUM_CLASSES = 5 // 0: Drawings, 1: Hentai, 2: Neutral, 3: Porn, 4: Sexy
    }

    init {
        val options = Interpreter.Options()
        val compatList = CompatibilityList()

        // Аппаратное ускорение: пробуем GPU Delegate, если нет - NNAPI (NPU), иначе 2 CPU потока
        if (compatList.isDelegateSupportedOnThisDevice) {
            gpuDelegate = GpuDelegate(compatList.bestOptionsForThisDevice)
            options.addDelegate(gpuDelegate)
        } else {
            nnApiDelegate = NnApiDelegate()
            options.addDelegate(nnApiDelegate)
        }
        options.setNumThreads(2)

        val modelBuffer = FileUtil.loadMappedFile(context, MODEL_PATH)
        interpreter = Interpreter(modelBuffer, options)
    }

    fun analyzeFrame(bitmap: Bitmap): DetectionResult {
        val startTime = System.currentTimeMillis()
        val scaledBitmap = Bitmap.createScaledBitmap(bitmap, INPUT_SIZE, INPUT_SIZE, true)
        
        // Преобразуем битмап в буфер 224x224x3 (INT8 нормализованный)
        val inputBuffer = ByteBuffer.allocateDirect(1 * INPUT_SIZE * INPUT_SIZE * 3)
        inputBuffer.order(ByteOrder.nativeOrder())
        
        val intValues = IntArray(INPUT_SIZE * INPUT_SIZE)
        scaledBitmap.getPixels(intValues, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE)
        
        for (pixel in intValues) {
            val r = (pixel shr 16 and 0xFF).toByte()
            val g = (pixel shr 8 and 0xFF).toByte()
            val b = (pixel and 0xFF).toByte()
            inputBuffer.put(r)
            inputBuffer.put(g)
            inputBuffer.put(b)
        }

        // Выходной буфер вероятностей 5 классов
        val outputScores = Array(1) { ByteArray(NUM_CLASSES) }
        interpreter?.run(inputBuffer, outputScores)

        val scores = outputScores[0].map { (it.toInt() and 0xFF) / 255.0f }
        val pornScore = scores[3]
        val hentaiScore = scores[1]
        val sexyScore = scores[4]

        // Критерий опасного контента
        val maxNsfwScore = maxOf(pornScore, hentaiScore, sexyScore * 0.75f)
        val isNsfw = maxNsfwScore > 0.72f

        return DetectionResult(
            isNsfw = isNsfw,
            confidence = maxNsfwScore,
            category = if (pornScore > 0.6f) "porn" else if (hentaiScore > 0.6f) "hentai" else "sexy",
            inferenceTimeMs = System.currentTimeMillis() - startTime
        )
    }

    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
        nnApiDelegate?.close()
    }
}
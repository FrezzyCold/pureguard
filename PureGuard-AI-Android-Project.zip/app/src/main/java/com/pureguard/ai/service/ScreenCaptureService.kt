package com.pureguard.ai.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.pureguard.ai.R
import com.pureguard.ai.ai.NsfwDetector
import com.pureguard.ai.ai.FrameDiffEngine
import com.pureguard.ai.overlay.BlockerOverlayManager
import kotlinx.coroutines.*

class ScreenCaptureService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())

    private lateinit var detector: NsfwDetector
    private lateinit var diffEngine: FrameDiffEngine
    private lateinit var overlayManager: BlockerOverlayManager

    override fun onCreate() {
        super.onCreate()
        detector = NsfwDetector(this)
        diffEngine = FrameDiffEngine(thresholdPercent = 10f)
        overlayManager = BlockerOverlayManager(this)
        startForeground(NOTIFICATION_ID, createNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("RESULT_CODE", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = intent?.getParcelableExtra<Intent>("DATA")

        if (resultCode == Activity.RESULT_OK && data != null) {
            val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)
            setupVirtualDisplay()
        }
        return START_STICKY
    }

    private fun setupVirtualDisplay() {
        val metrics = resources.displayMetrics
        val width = 224 // Сжимаем сразу в разрешение нейросети для экономии RAM/CPU!
        val height = (224 * (metrics.heightPixels.toFloat() / metrics.widthPixels)).toInt()

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "PureGuardCapture",
            width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        // Слушатель поступления новых кадров
        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            serviceScope.launch {
                try {
                    val bitmap = imageToBitmap(image)
                    image.close()

                    // УМНЫЙ ДИФФ-ФИЛЬТР: Проверяем, изменился ли экран хотя бы на 10%
                    if (diffEngine.hasSignificantChange(bitmap)) {
                        val result = detector.analyzeFrame(bitmap)
                        if (result.isNsfw && result.confidence > 0.75f) {
                            withContext(Dispatchers.Main) {
                                // 1. Выбрасываем на домашний экран (GLOBAL_ACTION_HOME)
                                PureGuardAccessibilityService.instance?.sendHomeAction()
                                
                                // 2. Показываем полноэкранный щит с оповещением
                                overlayManager.showSexualContentDetectedShield(
                                    reason = "Замечен Сексуальный контент",
                                    confidence = result.confidence
                                )
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }, null)
    }

    private fun createNotification(): Notification {
        val channelId = "pureguard_active_shield"
        val channel = NotificationChannel(channelId, "PureGuard AI Shield", NotificationManager.IMPORTANCE_LOW)
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("PureGuard AI Активен")
            .setContentText("Экран смартфона защищен от сексуального контента")
            .setSmallIcon(R.drawable.ic_shield)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        detector.close()
        virtualDisplay?.release()
        mediaProjection?.stop()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val NOTIFICATION_ID = 1001
    }
}
package com.pureguard.ai.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import com.pureguard.ai.R
import java.util.Locale

class BlockerOverlayManager(private val context: Context) : TextToSpeech.OnInitListener {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: View? = null
    private var tts: TextToSpeech? = TextToSpeech(context, this)

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ru", "RU")
        }
    }

    fun showSexualContentDetectedShield(reason: String, confidence: Float) {
        if (overlayView != null) return // Уже показан

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        val inflater = LayoutInflater.from(context)
        overlayView = inflater.inflate(R.layout.overlay_shield_blocked, null).apply {
            findViewById<TextView>(R.id.tvAlertTitle).text = "⚠️ ЗАМЕЧЕН СЕКСУАЛЬНЫЙ КОНТЕНТ"
            findViewById<TextView>(R.id.tvAlertSubtitle).text = 
                "Нейросеть зафиксировала запрещенный визуальный материал (уверенность: ${(confidence * 100).toInt()}%)."
            
            findViewById<Button>(R.id.btnAcknowledge).setOnClickListener {
                dismiss()
            }
        }

        windowManager.addView(overlayView, params)

        // 1. Озвучиваем голосовое предупреждение: "Замечен сексуальный контент"
        tts?.speak("Замечен сексуальный контент! Приложение закрыто.", TextToSpeech.QUEUE_FLUSH, null, "nsfw_alert")

        // 2. Тревожная вибрация
        triggerAlertVibration()
    }

    private fun triggerAlertVibration() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator.vibrate(
                VibrationEffect.createWaveform(longArrayOf(0, 200, 100, 200, 100, 300), -1)
            )
        } else {
            @Suppress("DEPRECATION")
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vibrator.vibrate(longArrayOf(0, 200, 100, 200, 100, 300), -1)
        }
    }

    fun dismiss() {
        overlayView?.let {
            windowManager.removeView(it)
            overlayView = null
        }
    }
}
# PureGuard AI — Android On-Device NSFW Screen Blocker

Автономный блокировщик сексуального контента на телефоне:
- MediaProjection API (захват экрана)
- TensorFlow Lite INT8 (локальная MobileNetV3 модель)
- AccessibilityService (мгновенный выброс на Home Screen)
- System Alert Window (экран блокировки)
- TextToSpeech (голосовое оповещение "Замечен сексуальный контент!")

## Сборка APK прямо с телефона через GitHub Actions (без компьютера):
1. Зарегистрируйтесь на github.com прямо с телефона.
2. Создайте новый приватный репозиторий "PureGuard".
3. Распакуйте и загрузите файлы из этого архива.
4. Перейдите во вкладку **Actions** -> нажмите **Run workflow**.
5. Через 2-3 минуты скачайте готовый файл **app-debug.apk** прямо на свой телефон!
